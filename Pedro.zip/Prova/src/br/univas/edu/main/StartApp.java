package br.univas.edu.main;
import br.edu.univas.vo.Aluno;
public class StartApp {
	public void ArrayList() {
		Aluno aluno = new Aluno();
		System.out.println("Nome do Aluno: ");
		System.out.println("CPF do Aluno: ");
		System.out.println("E-mail do Aluno: ");
		
		
		
		
		

		
	}

		
		
	

}
